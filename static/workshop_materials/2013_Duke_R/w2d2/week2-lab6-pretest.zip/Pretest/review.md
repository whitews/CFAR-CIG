Review of basic programming tools in R
========================================================

These examples may come in useful for solving the Pretest challenges!

String manipulation
--------------------

One of the basic string functions is ```paste```. LIke its name suggests, it pastes items togehter, coercing them into characters first if necessary. A couople of examples will make its usage clear.


```r
paste("Hello", "world")
```

```
## [1] "Hello world"
```

```r
paste("foo", 1:10, ".txt", sep = "")
```

```
##  [1] "foo1.txt"  "foo2.txt"  "foo3.txt"  "foo4.txt"  "foo5.txt" 
##  [6] "foo6.txt"  "foo7.txt"  "foo8.txt"  "foo9.txt"  "foo10.txt"
```


Output is usually done with ```print``` but ```cat``` is also useful.

```r
print(paste("Hello", "world"))
```

```
## [1] "Hello world"
```

```r
cat("Hello", "world")
```

```
## Hello world
```


Sampling
---------
Sampling operations are very common in statistics, for example, in permutation or bootstrap operations. Sampling is also used to generate dummy data examples.

```r
# sample without replacement
sample(1:10, replace = F)
```

```
##  [1]  3  4  9  2 10  8  1  7  5  6
```

```r

# sample with replacement
sample(1:10, replace = T)
```

```
##  [1] 1 8 6 8 6 5 7 8 7 6
```

```r

obese.outcomes <- data.frame(IDs = sample(10000:99999, 10, replace = F), weight = rnorm(10, 
    350, 50), treatment = sample(c("Drugs", "Surgery"), 10, replace = T))
obese.outcomes
```

```
##      IDs weight treatment
## 1  28657  309.2   Surgery
## 2  27390  397.8   Surgery
## 3  87527  375.3   Surgery
## 4  73734  342.6   Surgery
## 5  92495  397.9   Surgery
## 6  98040  334.7     Drugs
## 7  18405  372.7     Drugs
## 8  78275  384.1     Drugs
## 9  29838  383.6   Surgery
## 10 53567  317.9   Surgery
```

```r

# If you wre a psychologist and wanted to test students abilty to memorize
# nonsense words, heere is one way to make up some random 5 letter words.
# Note tht letters is a built in vector consiting of the 26 lower case
# letters of the alphabet.
for (i in 1:10) {
    word <- sample(letters, 5, replace = T)
    cat(word, "\n", sep = "")
}
```

```
## vygsp
## nmvge
## juzdh
## buxip
## iioau
## djsfv
## bsczq
## orihl
## opcmz
## tlnkp
```


Sorting and ordering
--------------------

```r
word <- sample(LETTERS, 10, replace = F)
word
```

```
##  [1] "A" "P" "I" "Y" "W" "J" "V" "U" "E" "M"
```

```r
sort(word)
```

```
##  [1] "A" "E" "I" "J" "M" "P" "U" "V" "W" "Y"
```

```r
sort(word, decreasing = T)
```

```
##  [1] "Y" "W" "V" "U" "P" "M" "J" "I" "E" "A"
```

```r

# order returns a vector of the order of items needed to sort the
# collection. So we can replicate sort using order and indexing.
idx <- order(word)
idx
```

```
##  [1]  1  9  3  6 10  2  8  7  5  4
```

```r
word[idx]
```

```
##  [1] "A" "E" "I" "J" "M" "P" "U" "V" "W" "Y"
```

```r

# order comes in very useful when we want to sort by only one row or column
# in a matrix or data frame. For example, to sort rows by the weights of
# obese subjects
obese.outcomes <- data.frame(IDs = sample(10000:99999, 10, replace = F), weight = rnorm(10, 
    350, 50), treatment = sample(c("Drugs", "Surgery"), 10, replace = T))
idx <- order(obese.outcomes$weight)
obese.outcomes[idx, ]
```

```
##      IDs weight treatment
## 2  14929  281.3   Surgery
## 10 36173  283.7     Drugs
## 9  70195  286.9   Surgery
## 3  71311  290.3   Surgery
## 5  86826  317.5   Surgery
## 8  55660  323.3   Surgery
## 4  47251  344.2     Drugs
## 1  25217  356.7     Drugs
## 6  26289  365.1     Drugs
## 7  24228  406.5     Drugs
```

```r

# try sorting by subject ID yourself
```




Control structures
------------------

Use ```for``` to do repeat operations
-----------------------------


```r
# We can treat NULL as an empty vector and grow the vector by one each time
# through the loop.
sq1 <- NULL
for (i in 1:10) {
    sq1 <- c(sq1, i^2)
}
sq1
```

```
##  [1]   1   4   9  16  25  36  49  64  81 100
```

```r

# However, it is much faster to use vectorized operations where possible
sq2 <- (1:10)^2
sq2
```

```
##  [1]   1   4   9  16  25  36  49  64  81 100
```


Use ```if``` to make decisions
--------------------------------


```r
scores <- c(56, 92, 73, 88, 99, 89)
for (i in 1:length(scores)) {
    if (scores[i] >= 90) {
        print(paste(i, scores[i], "Distinction"))
    } else if (scores[i] >= 70) {
        print(paste(i, scores[i], "Pass"))
    } else {
        print(paste(i, scores[i], "Fail"))
    }
}
```

```
## [1] "1 56 Fail"
## [1] "2 92 Distinction"
## [1] "3 73 Pass"
## [1] "4 88 Pass"
## [1] "5 99 Distinction"
## [1] "6 89 Pass"
```

```r

# There is also a vectorized if-else statement that is much faster if
# applicable. It takes 3 arguments - the 'test', the result if the test is
# true, the result if the test is false.
x <- 1:10
ifelse(x%%2 == 0, x^2, x)
```

```
##  [1]   1   4   3  16   5  36   7  64   9 100
```


Writing custom functions
------------------------

You have already seen examples of many R functions. Functions are the foundation of R programming, and you will now learn how to write your own custom functions. Think of a funciton as a BLACK BOX taht takes some input, does something with it, and returns an  output. The basic structure of a function is shown below.

```r
function.name <- function(arg1, arg2, arg3) {
    # body of function
}
```


Basically, a function takes inputs in the form of its arguments, and returns the LAST value in the body. Here is a simple example.

```r
add <- function(a, b) {
    a + b
}
add(3, 4)
```

```
## [1] 7
```


If you want to return more than 1 value, put it in a collection (list, vector, matrix, dataframe)

```r
make.list <- function(a, b) {
    c(a, b)
}
make.list(3, 4)
```

```
## [1] 3 4
```


Functinos can be given defaults

```r
add <- function(a = 10, b = 20) {
    a + b
}

add()
```

```
## [1] 30
```

```r
add(3)
```

```
## [1] 23
```

```r
add(b = 6)
```

```
## [1] 16
```

```r
add(3, 4)
```

```
## [1] 7
```


You can of course, use previously defined functions within new functions.

```r
double <- function(x) {
    x * 2
}

quadruple <- function(x) {
    double(double(x))
}

quadruple(4)
```

```
## [1] 16
```



The ```apply``` family of functions
----------------------------------

We are normaly working with very large data sets, and often need to apply functions to groups of variables without tedious looping. The ```apply``` family of functions lets us do this efficiently.

We know how to apply a function to a vector.

```r
x <- 10:15
mean(x)
```

```
## [1] 12.5
```


How do we apply a function to all rows or columns of a matrix or dataframe? Use ```apply```.

```r
x <- matrix(1:20, nrow = 4)
x
```

```
##      [,1] [,2] [,3] [,4] [,5]
## [1,]    1    5    9   13   17
## [2,]    2    6   10   14   18
## [3,]    3    7   11   15   19
## [4,]    4    8   12   16   20
```

```r
# find row means
apply(x, FUN = mean, MARGIN = 1)
```

```
## [1]  9 10 11 12
```

```r
# find column max
apply(x, FUN = max, MARGIN = 2)
```

```
## [1]  4  8 12 16 20
```


What about for a list?

```r
ys <- list(ages = c(10, 12, 9, 11, 14, 16), heights = c(172, 183, 166, 146, 
    174, 166))
sapply(ys, FUN = mean)
```

```
##    ages heights 
##    12.0   167.8
```


What about data frames with categorical factors?

```r
xs <- data.frame(patient = 1:100, age = rnorm(100, mean = 60, sd = 12), treatment = sample(c("Treatment", 
    "Control"), 100, replace = T))
head(xs)
```

```
##   patient   age treatment
## 1       1 64.24   Control
## 2       2 54.74 Treatment
## 3       3 51.49 Treatment
## 4       4 59.29   Control
## 5       5 59.70 Treatment
## 6       6 60.24 Treatment
```

```r

# we can use tapply to find the mean age in each treatment group. You can
# think of tapply as partitioning the data set based on the IND argument,
# then applying the FUN argument to each partition of the data.
tapply(xs$age, IND = xs$treatment, FUN = mean)
```

```
##   Control Treatment 
##     59.90     61.13
```




